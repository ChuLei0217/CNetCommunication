#include <CNetCommunication.h>
#include <QtNetwork/QNetworkAccessManager>
#include <QtNetwork/QNetworkRequest>
#include <QtNetwork/QNetworkReply>
#include <QJsonObject>
#include <QJsonDocument>
#include <QtCore/QCoreApplication>

int main(int argc, char *argv[])
{
	QCoreApplication a(argc, argv);
	QJsonObject obj;
	obj.insert("warnings.deviceserial", QString("12345"));
	obj.insert("warnings.warningType", QString("1"));
	obj.insert("warnings.roomAreaTypeId", QString("3"));
	obj.insert("warnings.warningState", int("0"));
	obj.insert("warnings.startTime", QString("2017-2-1 00:00:00"));
	obj.insert("warnings.endTime", QString("2017-2-1 00:00:00"));
	QJsonDocument * jjj = &QJsonDocument(obj);
	QUrl u = "http://211.67.27.249:8080/MonitorWeb/warning/warning_add.action?warnings.deviceserial=786297833&warnings.warningType=1&warnings.roomAreaTypeId=2&warnings.warningState=0&warnings.startTime=2017-11-12&warnings.endTime=2017-11-13";
	QUrl *uu = &u;
	CNetCommunication * test = new CNetCommunication(uu, jjj);
	test->PostWarningInfo();
	bool result = test->ReturnStatus();
	system("pause");
	return a.exec();
}
