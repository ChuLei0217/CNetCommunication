#include <CNetCommunication.h>
const int HTTP_TIME = 10000; //10��

CNetCommunication::CNetCommunication(QUrl * url, QJsonDocument * jsondocument)
{
	this->url = url;
	this->jsondocument = jsondocument;
	manager = new QNetworkAccessManager(this);
	reply = NULL;
	status = NULL;
	timer = new QTimer;
	connect(timer, SIGNAL(timeout()), this, SLOT(slot_requestTimeout()));//��ʱ�ź�
}

void CNetCommunication::PostWarningInfo()
{
	QNetworkRequest request;
	request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json;charset=UTF-8");
	request.setUrl(*url); //��ַ��Ϣ
	if (jsondocument != NULL)
	{
		reply = manager->post(request, jsondocument->toJson()); //����post����
		connect(reply, SIGNAL(finished()), this, SLOT(slot_requestFinished())); //��������ź�
		timer->start(HTTP_TIME);
	}
}

bool CNetCommunication::slot_requestFinished()
{
	timer->stop();//�رն�ʱ��
	int nHttpCode = reply->attribute(QNetworkRequest::HttpStatusCodeAttribute).toInt();//http������
	if (nHttpCode == 200)//�ɹ�
	{
		//����ɹ�
		return status = true;
	}
	else
	{
		//����ʧ��
		return status = false;
	}
	reply->deleteLater();
	this->deleteLater(); //�ͷ��ڴ�
}

bool CNetCommunication::slot_requestTimeout()
{
	//����ʧ��
	reply->deleteLater();
	this->deleteLater();//�ͷ��ڴ�
	return status = false;
}


bool CNetCommunication::ReturnStatus()
{
	return status;
	status = NULL;
}
